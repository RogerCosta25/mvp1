// src/App.js
import React from 'react';
import ComparisonTable from './components/ComparisonTable';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-bold text-center mb-8">Comparativo de Plataformas para Fábrica de Softwares</h1>
      <ComparisonTable />
    </div>
  );
}

export default App;