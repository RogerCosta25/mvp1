// src/components/ComparisonTable.js
import React from 'react';

const platforms = [
  {
    name: 'MetaGPT',
    easeOfUse: 'Alta',
    scalability: 'Alta',
    noCodeLowCode: 'Sim',
    integrations: 'Ampla',
    cost: 'Médio'
  },
  {
    name: 'FastAgency',
    easeOfUse: 'Média',
    scalability: 'Alta',
    noCodeLowCode: 'Sim',
    integrations: 'Ampla',
    cost: 'Baixo'
  },
  {
    name: 'Agentverse',
    easeOfUse: 'Alta',
    scalability: 'Média',
    noCodeLowCode: 'Sim',
    integrations: 'Moderada',
    cost: 'Médio'
  },
  {
    name: 'Project Mariner',
    easeOfUse: 'Alta',
    scalability: 'Alta',
    noCodeLowCode: 'Não',
    integrations: 'Ampla',
    cost: 'Alto'
  },
  {
    name: 'Vertex AI',
    easeOfUse: 'Média',
    scalability: 'Alta',
    noCodeLowCode: 'Sim',
    integrations: 'Ampla',
    cost: 'Alto'
  },
  {
    name: 'Stack AI',
    easeOfUse: 'Alta',
    scalability: 'Média',
    noCodeLowCode: 'Sim',
    integrations: 'Moderada',
    cost: 'Médio'
  },
  {
    name: 'Crew AI',
    easeOfUse: 'Alta',
    scalability: 'Alta',
    noCodeLowCode: 'Sim',
    integrations: 'Ampla',
    cost: 'Médio'
  },
  {
    name: 'Manus AI',
    easeOfUse: 'Alta',
    scalability: 'Alta',
    noCodeLowCode: 'Sim',
    integrations: 'Ampla',
    cost: 'Alto'
  }
];

const ComparisonTable = () => {
  return (
    <div className="overflow-x-auto bg-white rounded-lg shadow">
      <table className="min-w-full">
        <thead>
          <tr className="bg-gray-200">
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Plataforma</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Facilidade de Uso</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Escalabilidade</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No-Code/Low-Code</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Integrações</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Custo</th>
          </tr>
        </thead>
        <tbody>
          {platforms.map((platform, index) => (
            <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
              <td className="px-6 py-4 text-sm font-medium text-gray-900">{platform.name}</td>
              <td className="px-6 py-4 text-sm text-gray-500">{platform.easeOfUse}</td>
              <td className="px-6 py-4 text-sm text-gray-500">{platform.scalability}</td>
              <td className="px-6 py-4 text-sm text-gray-500">{platform.noCodeLowCode}</td>
              <td className="px-6 py-4 text-sm text-gray-500">{platform.integrations}</td>
              <td className="px-6 py-4 text-sm text-gray-500">{platform.cost}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ComparisonTable;